import{_ as e,o as c,c as r}from"./app.2ffb4457.js";const t={};function _(n,o){return c(),r("div")}var s=e(t,[["render",_],["__file","index.html.vue"]]);export{s as default};
