import{_ as e,o as _,c}from"./app.2ffb4457.js";const r={};function t(o,a){return _(),c("div")}var s=e(r,[["render",t],["__file","404.html.vue"]]);export{s as default};
