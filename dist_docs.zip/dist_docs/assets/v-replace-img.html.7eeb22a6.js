import{_ as e,o as c,c as r}from"./app.2ffb4457.js";const t={};function _(a,o){return c(),r("div")}var n=e(t,[["render",_],["__file","v-replace-img.html.vue"]]);export{n as default};
